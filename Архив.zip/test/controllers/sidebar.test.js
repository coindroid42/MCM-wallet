'use strict';
 
describe('sidebarController', function(){
  var scope, controller;

  beforeEach(angular.mock.module('copayApp.controllers'));

  it('wallet selection', function(){
    expect(true).not.toBeUndefined();
  });
});
