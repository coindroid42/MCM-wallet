'use strict';


angular.module('copayApp.services').factory('authService', function() {
    var root = {};

    root.objRequest = null;


    return root;
});
