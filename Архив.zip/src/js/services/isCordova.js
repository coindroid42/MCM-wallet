'use strict';

angular.module('copayApp.services').value('isCordova',  window.cordova ? true : false);
