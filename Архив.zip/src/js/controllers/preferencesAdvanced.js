'use strict';

angular.module('copayApp.controllers').controller('preferencesAdvancedController',
  function($scope) {

  });