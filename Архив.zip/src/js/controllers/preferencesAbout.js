'use strict';

angular.module('copayApp.controllers').controller('preferencesAbout',
  function() {});
